<!--This document is formatted in GitHub flavored markdown, tweaked for Github's
    presentation of the repo's README.md file. Documentation for GFM is at
    https://help.github.com/articles/github-flavored-markdown
    A semi-useful site for previewing GFM is available at
    http://tmpvar.com/markdown.html
-->
##Marvin Manager##

###JSON switches###
* `development_mode` controls verbose display of debug information
* `hash_caching_disabled` forces a reload of Marvin content every time
* `show_progress_as_percentage` changes the display of reading progress to numeric
* `use_monospace_font` changes the text style

---
Last update July 1, 2013 3:37:30 AM MDT
